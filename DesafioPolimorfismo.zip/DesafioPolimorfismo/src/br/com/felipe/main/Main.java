package br.com.felipe.main;
import br.com.felipe.funcionarios.*;
import java.util.List;
import java.util.ArrayList;

public class Main {
	
	public static void main(String args []) {
		
		List<Double> funcionario = new ArrayList<>();
		
		Funcionario func1 = new Funcionario("Thiago");
		System.out.println(func1.getSalario());
		Gerente func2 = new Gerente("Gabriel");
		System.out.println(func2.getSalario());
		Diretor func3 = new Diretor("Hugo");
		System.out.println(func3.getSalario());
		
		funcionario.add(func1.getSalario());
		
		
		
		
			
	}
	
	
}
