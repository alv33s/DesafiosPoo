package br.com.felipe.funcionarios;

public class Diretor  extends Funcionario{


	
	public Diretor(String nome) {
		super(nome);
		calculaSalario();
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculaSalario() {
		// TODO Auto-generated method stub
		setSalario(super.calculaSalario() * 2.0) ;
		return getSalario();
	}

}
