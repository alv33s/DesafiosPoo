package br.com.felipe.funcionarios;
import java.util.List;
import java.util.ArrayList;
import br.com.felipe.main.*;

public class FolhaPagamento {
	
	public void salarioFuncionarios(funcionario()) {
		
		
		
		
		
	}
	
	
}	
