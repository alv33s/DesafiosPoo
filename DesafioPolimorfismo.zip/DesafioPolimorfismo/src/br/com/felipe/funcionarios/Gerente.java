package br.com.felipe.funcionarios;

public class Gerente extends Funcionario {

	

	public Gerente(String nome) {
		super(nome);
		calculaSalario();
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculaSalario() {
		// TODO Auto-generated method stub
		setSalario(super.calculaSalario() * 1.5) ;
		return getSalario();
	}
	
	
}
